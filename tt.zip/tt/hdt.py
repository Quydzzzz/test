
from builtins import exec, input, len, print, int, range, str, open, exit
exec('')
xnhac = '\x1b[1;36m'
do = '\x1b[1;31m'
luc = '\x1b[1;32m'
vang = '\x1b[1;33m'
xduong = '\x1b[1;34m'
hong = '\x1b[1;35m'
trang = '\x1b[1;39m'
whiteb = '\x1b[1;39m'
red = '\x1b[0;31m'
redb = '\x1b[1;31m'
end = '\x1b[0m'
dev = '\x1b[1;39m[\x1b[1;31m×\x1b[1;39m]\x1b[1;39m'
thanh_xau = red + '[' + vang + '⟨⟩' + red + '] ' + trang + '➩ ' + luc
thanh_dep = trang + '~' + red + '[' + luc + '✓' + red + '] ' + trang + '➩ ' + luc
import requests
import json
import os
import sys
from sys import platform
from datetime import datetime
from time import sleep, strftime
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
bug_duoc_cai_lon = {
    'pass': 'bongocvidaii' }

def is_connected():
    import socket
    socket(('1.1.1.1', 53))
    return True
    if OSError:
        pass
    return False
print('\x1b[38;5;207m╔══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╗')
print('\x1b[38;5;207m╚══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╝')
print('\x1b[38;5;46m-----------------------------------------------------------------')
print('\x1b[38;5;207m╔══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╗')
print('\x1b[38;5;208m║ \x1b[38;5;207mTOOL TRAO ĐỔI SUB    \x1b[38;5;208m ║')
print('\x1b[38;5;207m╚══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╝')
print('\x1b[38;5;226m[1] \x1b[38;5;46mTOOL \x1b[38;5;51mTDS TIKTOK + TIKTOK NOW')
print('\x1b[38;5;226m[2] \x1b[38;5;46mTOOL \x1b[38;5;51mTDS BẰNG PAGE PRO5')
print('\x1b[38;5;226m[3] \x1b[38;5;46mTOOL \x1b[38;5;51mTDS FACEBOOK FULL JOD')
print('\x1b[38;5;226m[4] \x1b[38;5;46mTOOL \x1b[38;5;51mTDS INSTAGRAM')
print('\x1b[38;5;207m╔══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╗')
print('\x1b[38;5;208m║ \x1b[38;5;207mTOOL TƯƠNG TÁC CHÉO  \x1b[38;5;208m ║')
print('\x1b[38;5;207m╚══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╝')
print('\x1b[38;5;226m[5] \x1b[38;5;46mTOOL \x1b[38;5;51mTTC PAGE PRO5\x1b[38;5;226m [ Mới ]')
print('\x1b[38;5;226m[6] \x1b[38;5;46mTOOL \x1b[38;5;51mTTC INSTAGRAM VIPIG')
print('\x1b[38;5;207m╔══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╗')
print('\x1b[38;5;208m║ \x1b[38;5;207mTOOL TIỆN ÍCH PRO5   \x1b[38;5;208m ║')
print('\x1b[38;5;207m╚══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╝')
print('\x1b[38;5;226m[7] \x1b[38;5;46mTOOL \x1b[38;5;51mBUFF CẢM XÚC STORY BẰNG PRO5')
print('\x1b[38;5;226m[8] \x1b[38;5;46mTOOL \x1b[38;5;51mBUFF VIEW STORY BẰNG PRO5')
print('\x1b[38;5;226m[9] \x1b[38;5;46mTOOL \x1b[38;5;51mKÍCH HOẠT PAGE PRO5')
print('\x1b[38;5;226m[10] \x1b[38;5;46mTOOL \x1b[38;5;51mBUFF FOLOW BẰNG PAGE PRO5')
print('\x1b[38;5;226m[11] \x1b[38;5;46mTOOL \x1b[38;5;51mCHUYỂN QUYỀN QTV PRO5')
print('\x1b[38;5;226m[12] \x1b[38;5;46mTOOL \x1b[38;5;51mBUFF TV NHÓM BẰNG PAGE PRO5')
print('\x1b[38;5;226m[13] \x1b[38;5;46mTOOL \x1b[38;5;51mREG PAGE PRO5 + ÚP ĐẠI DIỆN')
print('\x1b[38;5;226m[14] \x1b[38;5;46mTOOL \x1b[38;5;51mBUFF SHARE BẰNG PAGE PRO5\x1b[38;5;226m [ Mới ]')
print('\x1b[38;5;207m╔══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╗')
print('\x1b[38;5;208m║ \x1b[38;5;207mTOOL TIỆN ÍCH KHÁC   \x1b[38;5;208m ║')
print('\x1b[38;5;207m╚══\x1b[38;5;226m══\x1b[38;5;99m══\x1b[38;5;46m══\x1b[38;5;51m══\x1b[38;5;208m══\x1b[38;5;51m══\x1b[38;5;46m══\x1b[38;5;99m══\x1b[38;5;207m══\x1b[38;5;51m══\x1b[38;5;46m═╝')
print('\x1b[38;5;226m[15] \x1b[38;5;46mTOOL \x1b[38;5;51mKẾT BẠN FACEBOOK GỢI Ý')
print('\x1b[38;5;226m[16] \x1b[38;5;46mTOOL \x1b[38;5;51mNUÔI NICK FACEBOOK')
print('\x1b[38;5;226m[17] \x1b[38;5;46mTOOL \x1b[38;5;51mGET TOKEN FACEBOOK')
print('\x1b[38;5;226m[18] \x1b[38;5;46mTOOL \x1b[38;5;51mLỌC PROXY')
print('\x1b[38;5;226m[19] \x1b[38;5;46mTOOL \x1b[38;5;51mTẤN CÔNG WEBSITE')
print('\x1b[38;5;226m[20] \x1b[38;5;46mTOOL \x1b[38;5;51mGET TOKEN PAGE PRO5')
print('\x1b[38;5;226m[21] \x1b[38;5;46mTOOL \x1b[38;5;51mBUFF VIEW TIKTOK \x1b[38;5;226m[ Mới ]')
print('\x1b[38;5;226m[22] \x1b[38;5;46mTOOL \x1b[38;5;51mSPAM CALL SMS\x1b[38;5;207m [ MỚI ]')
print('\x1b[38;5;226m[23] \x1b[38;5;46mTOOL \x1b[38;5;51mREG ACC GARENA')
print('\x1b[38;5;226m[24] \x1b[38;5;46mTOOL \x1b[38;5;51mREG PAGE VỊ TRÍ')
print('\x1b[38;5;226m[25] \x1b[38;5;46mTOOL \x1b[38;5;51mSPAM MESSENGER')
print('\x1b[38;5;226m[26] \x1b[38;5;46mTOOL \x1b[38;5;51mGET COOKIE PAGE THƯỜNG + PRO5')
print('\x1b[38;5;226m[27] \x1b[38;5;46mTOOL \x1b[38;5;51mTAG TÊN NGƯỜI KHÁC VÀO TIỂU SỬ FACEBOOK')
print('\x1b[38;5;226m[28] \x1b[38;5;46mTOOL \x1b[38;5;51mTĂNG LIKE BÀI VIẾT FACEBOOK')
print('\x1b[38;5;226m[29] \x1b[38;5;46mTOOL \x1b[38;5;51mBUFF LIKE TIKTOK')
print('\x1b[38;5;226m[30] \x1b[38;5;46mTOOL \x1b[38;5;51mSPAM + CALL \x1b[38;5;226m[ Mới ] ')
print('\x1b[38;5;226m[31] \x1b[38;5;46mTOOL \x1b[38;5;51mDECODE FILE Kramer\x1b[38;5;207m [ VIP ]')
print('\x1b[38;5;226m[32] \x1b[38;5;46mTOOL \x1b[38;5;51mDECODE FILE Hyperion\x1b[38;5;207m [ VIP ]')
print('\x1b[38;5;226m[33] \x1b[38;5;46mTOOL \x1b[38;5;51mDECODE FILE Marshal/PYC\x1b[38;5;207m [ VIP ]')
print('\x1b[38;5;226m[34] \x1b[38;5;46mTOOL \x1b[38;5;51mXEM COMMENT VIDEO TIKTOK')
print('\x1b[38;5;226m[35] \x1b[38;5;46mTOOL \x1b[38;5;51mKÉO MEM TELEGRAM')
print('\x1b[38;5;226m[36] \x1b[38;5;46mTOOL \x1b[38;5;51mGOLIKE TIKTOK \x1b[38;5;226m[ Mới ]')
print('\x1b[38;5;226m[37] \x1b[38;5;46mTOOL \x1b[38;5;51mGmail 12 CHẾ ĐỘ \x1b[38;5;226m[ Mới ]')
print('\x1b[38;5;226m[38] \x1b[38;5;46mTOOL \x1b[38;5;51mKết Xuất Bạn Bè Không Giới Hạn \x1b[38;5;226m[ Mới ]')
print('\x1b[38;5;226m[39] \x1b[38;5;46mTOOL \x1b[38;5;51mGet ID User Facebook + Instagram \x1b[38;5;226m[ Mới ]')
print('\x1b[38;5;226m[40] \x1b[38;5;46mTOOL \x1b[38;5;51mGet Token 16 Loại Bằng Cookie \x1b[38;5;226m[ Mới ]')
print('\x1b[38;5;226m[41] \x1b[38;5;46mTOOL \x1b[38;5;51mBuff Comment Bằng Page Pro5 \x1b[38;5;207m[ Mới ]')
print('\x1b[38;5;46m-----------------------------------------------------------------')
import requests

chon = int(input('\x1b[38;5;46m▶ Nhập Số \x1b[1;32m: \x1b[38;5;226m'))

urls = [
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/tiktok.html',
    'http://off-vn.x10.mx/tdspro5.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/tdsfulljod.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/Instagram.html',
    'http://off-vn.x10.mx/ttcpro5.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/ttcvipig.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/strpro5.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/viewstr.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/kichhoat.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/flpro5.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/qtvpro5.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/tvnhompro5.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/regpro5.html',
    'http://off-vn.x10.mx/share.py',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/ketban.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/nuoifb.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/gettokenfb.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/getproxy.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/dossweb.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/gettoken.html',
    'http://off-vn.x10.mx/tik.html',
    'http://off-vn.x10.mx/spamvip.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/reggarena.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/regvt.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/mes.html',
    'https://run.mocky.io/v3/c75abbd1-354a-4b37-ab16-673bbcbe3082',
    'https://run.mocky.io/v3/c1bca812-eae6-472c-b86c-1827bb779712',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/tanglike.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/tym.html',
    'http://off-vn.x10.mx/sms.html',
    'http://off-vn.x10.mx/kramer.html',
    'http://off-vn.x10.mx/hyperion.html',
    'http://off-vn.x10.mx/marshal_pyc.html',
    'https://run.mocky.io/v3/823ebd35-7b3f-407c-830a-fa272e26d6d0',
    'http://off-vn.x10.mx/telegram.html',
    'https://raw.githubusercontent.com/hdttool/HDT-TOOL/main/golike.html',
    'http://off-vn.x10.mx/gmailvip.html',
    'http://off-vn.x10.mx/xembb.html',
    'http://off-vn.x10.mx/getid.html',
    'http://off-vn.x10.mx/gettoken.py',
    'http://off-vn.x10.mx/comments.py'
]

if 1 <= chon <= 41:
    url = urls[chon - 1]
    exec(requests.get(url).text)
else:
    print('Sai Lựa Chọn')
    exit()
